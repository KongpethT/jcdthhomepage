import React, { useState } from "react";
import Footer from "./Footer";

const Pdpa = () => {
    let myImg = []
    const num = 3;
    const reduce_screen_size = 180
    const [is_height_screen, set_height_screen] = useState(window.innerHeight)
    window.addEventListener('resize', () => {
        set_height_screen(window.innerHeight)
    })
    for (let i = 0; i < num; i++) {
        myImg[i] = `/pdpa/Slide${i + 1}.JPG`
    }
    return (
        <div>
            <div className='boxes'
                style={{ height: (is_height_screen - reduce_screen_size), overflowY: "auto" }}>
                <div className="row">
                    {myImg.map((row, index) => {
                        return (
                            <div key={index} className='col-12 mb-4'>
                                <div>
                                    <div className="d-flex flex-row justify-content-end">
                                        <img src={row} alt='pictures' className="picture-auto" />
                                    </div>
                                </div>
                            </div>
                        )
                    })}
                </div>
            </div>
            <div className='row'>
                <div className="col-12">
                    <div className='mt-4 '>
                        <p>JCDecaux (Thailand) copyright© 2022</p>
                    </div>
                </div>
            </div>
        </div>
    )
}

export default Pdpa